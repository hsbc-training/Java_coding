package com.hsbc.model;

public class Contractor extends Employee {

	@Override
	float getSalary() {
		return 30000;
	}

}
