package com.hsbc.model;

public class HRStaff extends Employee {

	@Override
	float getSalary() {
		// TODO Auto-generated method stub
		return 24000;
	}

}
