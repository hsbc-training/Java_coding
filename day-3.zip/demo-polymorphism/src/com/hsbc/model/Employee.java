package com.hsbc.model;

public abstract class Employee {
	abstract float getSalary();
}
