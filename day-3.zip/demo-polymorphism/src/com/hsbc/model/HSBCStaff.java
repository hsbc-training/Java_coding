package com.hsbc.model;

public class HSBCStaff extends Employee {

	@Override
	float getSalary() {
		return 40000;
	}

}
